class PeliculaRepository():
    def __init__(self, peliculas=None):
        self.peliculas = peliculas
