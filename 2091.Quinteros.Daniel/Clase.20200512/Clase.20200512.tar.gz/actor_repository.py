class ActorRepository():
    def __init__(self, actores=None):
        self.actores = actores
